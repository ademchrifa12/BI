using Microsoft.EntityFrameworkCore;
using WideWorldImportersBI.Entities.DataWarehouse;

namespace WideWorldImportersBI.Data.DataWarehouse;

/// <summary>
/// Entity Framework DbContext for the Data Warehouse database
/// This context is used for BI analytics and reporting
/// Will be populated by ETL processes (SSIS or similar)
/// </summary>
public class DwDbContext : DbContext
{
    public DwDbContext(DbContextOptions<DwDbContext> options) : base(options)
    {
    }

    // Fact Tables
    public DbSet<FactSales> FactSales { get; set; } = null!;

    // Dimension Tables
    public DbSet<DimCustomer> DimCustomers { get; set; } = null!;
    public DbSet<DimProduct> DimProducts { get; set; } = null!;
    public DbSet<DimDate> DimDates { get; set; } = null!;

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        base.OnModelCreating(modelBuilder);

        // Configure FactSales entity
        modelBuilder.Entity<FactSales>(entity =>
        {
            entity.ToTable("FactSales", "DW");
            entity.HasKey(e => e.SalesKey);

            // Create indexes for common query patterns
            entity.HasIndex(e => e.DateKey).HasDatabaseName("IX_FactSales_DateKey");
            entity.HasIndex(e => e.CustomerKey).HasDatabaseName("IX_FactSales_CustomerKey");
            entity.HasIndex(e => e.ProductKey).HasDatabaseName("IX_FactSales_ProductKey");
            entity.HasIndex(e => new { e.DateKey, e.CustomerKey, e.ProductKey })
                  .HasDatabaseName("IX_FactSales_Composite");

            // Configure decimal precision
            entity.Property(e => e.UnitPrice).HasPrecision(18, 2);
            entity.Property(e => e.TotalAmount).HasPrecision(18, 2);
            entity.Property(e => e.TaxAmount).HasPrecision(18, 2);
            entity.Property(e => e.Profit).HasPrecision(18, 2);
            entity.Property(e => e.TotalIncludingTax).HasPrecision(18, 2);

            // Configure relationships
            entity.HasOne(f => f.Date)
                  .WithMany(d => d.Sales)
                  .HasForeignKey(f => f.DateKey)
                  .OnDelete(DeleteBehavior.Restrict);

            entity.HasOne(f => f.Customer)
                  .WithMany(c => c.Sales)
                  .HasForeignKey(f => f.CustomerKey)
                  .OnDelete(DeleteBehavior.Restrict);

            entity.HasOne(f => f.Product)
                  .WithMany(p => p.Sales)
                  .HasForeignKey(f => f.ProductKey)
                  .OnDelete(DeleteBehavior.Restrict);
        });

        // Configure DimCustomer entity
        modelBuilder.Entity<DimCustomer>(entity =>
        {
            entity.ToTable("DimCustomer", "DW");
            entity.HasKey(e => e.CustomerKey);

            entity.HasIndex(e => e.CustomerId).HasDatabaseName("IX_DimCustomer_BusinessKey");
            entity.HasIndex(e => e.IsCurrent).HasDatabaseName("IX_DimCustomer_IsCurrent");
            entity.HasIndex(e => e.CustomerCategory).HasDatabaseName("IX_DimCustomer_Category");

            entity.Property(e => e.CreditLimit).HasPrecision(18, 2);
            entity.Property(e => e.StandardDiscountPercentage).HasPrecision(18, 3);
        });

        // Configure DimProduct entity
        modelBuilder.Entity<DimProduct>(entity =>
        {
            entity.ToTable("DimProduct", "DW");
            entity.HasKey(e => e.ProductKey);

            entity.HasIndex(e => e.StockItemId).HasDatabaseName("IX_DimProduct_BusinessKey");
            entity.HasIndex(e => e.IsCurrent).HasDatabaseName("IX_DimProduct_IsCurrent");
            entity.HasIndex(e => e.Brand).HasDatabaseName("IX_DimProduct_Brand");

            entity.Property(e => e.UnitPrice).HasPrecision(18, 2);
            entity.Property(e => e.RecommendedRetailPrice).HasPrecision(18, 2);
            entity.Property(e => e.TaxRate).HasPrecision(18, 3);
            entity.Property(e => e.TypicalWeightPerUnit).HasPrecision(18, 3);
        });

        // Configure DimDate entity
        modelBuilder.Entity<DimDate>(entity =>
        {
            entity.ToTable("DimDate", "DW");
            entity.HasKey(e => e.DateKey);

            entity.HasIndex(e => e.Date).HasDatabaseName("IX_DimDate_Date");
            entity.HasIndex(e => e.Year).HasDatabaseName("IX_DimDate_Year");
            entity.HasIndex(e => e.YearMonth).HasDatabaseName("IX_DimDate_YearMonth");
            entity.HasIndex(e => new { e.Year, e.Month }).HasDatabaseName("IX_DimDate_YearMonth_Composite");
        });
    }
}
