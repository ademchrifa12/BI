using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace WideWorldImportersBI.Entities.DataWarehouse;

/// <summary>
/// Fact table for sales analytics in the Data Warehouse
/// This entity will be populated by ETL processes from the OLTP database
/// Used for: Sales KPIs, Revenue analysis, Time-based trends
/// </summary>
[Table("FactSales", Schema = "DW")]
public class FactSales
{
    [Key]
    [Column("SalesKey")]
    public long SalesKey { get; set; }

    /// <summary>
    /// Foreign key to DimDate for date-based analysis
    /// </summary>
    [Column("DateKey")]
    public int DateKey { get; set; }

    /// <summary>
    /// Foreign key to DimCustomer for customer-based analysis
    /// </summary>
    [Column("CustomerKey")]
    public int CustomerKey { get; set; }

    /// <summary>
    /// Foreign key to DimProduct for product-based analysis
    /// </summary>
    [Column("ProductKey")]
    public int ProductKey { get; set; }

    /// <summary>
    /// Original InvoiceID from the OLTP system for lineage tracking
    /// </summary>
    [Column("InvoiceID")]
    public int InvoiceId { get; set; }

    /// <summary>
    /// Original InvoiceLineID from the OLTP system for lineage tracking
    /// </summary>
    [Column("InvoiceLineID")]
    public int InvoiceLineId { get; set; }

    /// <summary>
    /// Quantity sold
    /// </summary>
    [Column("Quantity")]
    public int Quantity { get; set; }

    /// <summary>
    /// Unit price at the time of sale
    /// </summary>
    [Column("UnitPrice")]
    public decimal UnitPrice { get; set; }

    /// <summary>
    /// Total line amount before tax
    /// </summary>
    [Column("TotalAmount")]
    public decimal TotalAmount { get; set; }

    /// <summary>
    /// Tax amount for this line
    /// </summary>
    [Column("TaxAmount")]
    public decimal TaxAmount { get; set; }

    /// <summary>
    /// Profit for this line
    /// </summary>
    [Column("Profit")]
    public decimal Profit { get; set; }

    /// <summary>
    /// Total amount including tax
    /// </summary>
    [Column("TotalIncludingTax")]
    public decimal TotalIncludingTax { get; set; }

    /// <summary>
    /// ETL load timestamp for data lineage
    /// </summary>
    [Column("LoadDateTime")]
    public DateTime LoadDateTime { get; set; }

    /// <summary>
    /// ETL batch identifier for troubleshooting
    /// </summary>
    [Column("ETLBatchID")]
    public int? EtlBatchId { get; set; }

    // Navigation properties
    [ForeignKey("DateKey")]
    public virtual DimDate? Date { get; set; }

    [ForeignKey("CustomerKey")]
    public virtual DimCustomer? Customer { get; set; }

    [ForeignKey("ProductKey")]
    public virtual DimProduct? Product { get; set; }
}
