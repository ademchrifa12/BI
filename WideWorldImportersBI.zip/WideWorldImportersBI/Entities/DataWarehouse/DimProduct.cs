using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace WideWorldImportersBI.Entities.DataWarehouse;

/// <summary>
/// Product dimension table for the Data Warehouse
/// This entity represents denormalized product/stock item data for BI analytics
/// SCD Type 2 support with ValidFrom/ValidTo for historical analysis
/// </summary>
[Table("DimProduct", Schema = "DW")]
public class DimProduct
{
    [Key]
    [Column("ProductKey")]
    public int ProductKey { get; set; }

    /// <summary>
    /// Original StockItemID from the OLTP system (business key)
    /// </summary>
    [Column("StockItemID")]
    public int StockItemId { get; set; }

    /// <summary>
    /// Product/Stock item name
    /// </summary>
    [Required]
    [MaxLength(100)]
    [Column("ProductName")]
    public string ProductName { get; set; } = string.Empty;

    /// <summary>
    /// Product brand for brand analysis
    /// </summary>
    [MaxLength(50)]
    [Column("Brand")]
    public string? Brand { get; set; }

    /// <summary>
    /// Product size specification
    /// </summary>
    [MaxLength(20)]
    [Column("Size")]
    public string? Size { get; set; }

    /// <summary>
    /// Color for product attribute analysis
    /// </summary>
    [MaxLength(50)]
    [Column("Color")]
    public string? Color { get; set; }

    /// <summary>
    /// Supplier name for supplier analysis
    /// </summary>
    [MaxLength(100)]
    [Column("Supplier")]
    public string? Supplier { get; set; }

    /// <summary>
    /// Unit price at the time of the record
    /// </summary>
    [Column("UnitPrice")]
    public decimal UnitPrice { get; set; }

    /// <summary>
    /// Recommended retail price for margin analysis
    /// </summary>
    [Column("RecommendedRetailPrice")]
    public decimal? RecommendedRetailPrice { get; set; }

    /// <summary>
    /// Tax rate applicable to the product
    /// </summary>
    [Column("TaxRate")]
    public decimal TaxRate { get; set; }

    /// <summary>
    /// Unit package type for packaging analysis
    /// </summary>
    [MaxLength(50)]
    [Column("UnitPackage")]
    public string? UnitPackage { get; set; }

    /// <summary>
    /// Outer package type
    /// </summary>
    [MaxLength(50)]
    [Column("OuterPackage")]
    public string? OuterPackage { get; set; }

    /// <summary>
    /// Quantity per outer package
    /// </summary>
    [Column("QuantityPerOuter")]
    public int QuantityPerOuter { get; set; }

    /// <summary>
    /// Flag indicating chiller stock requirement
    /// </summary>
    [Column("IsChillerStock")]
    public bool IsChillerStock { get; set; }

    /// <summary>
    /// Lead time in days for inventory analysis
    /// </summary>
    [Column("LeadTimeDays")]
    public int LeadTimeDays { get; set; }

    /// <summary>
    /// Typical weight per unit for logistics analysis
    /// </summary>
    [Column("TypicalWeightPerUnit")]
    public decimal TypicalWeightPerUnit { get; set; }

    /// <summary>
    /// SCD Type 2: Record validity start
    /// </summary>
    [Column("ValidFrom")]
    public DateTime ValidFrom { get; set; }

    /// <summary>
    /// SCD Type 2: Record validity end
    /// </summary>
    [Column("ValidTo")]
    public DateTime ValidTo { get; set; }

    /// <summary>
    /// SCD Type 2: Current record flag
    /// </summary>
    [Column("IsCurrent")]
    public bool IsCurrent { get; set; }

    /// <summary>
    /// ETL load timestamp
    /// </summary>
    [Column("LoadDateTime")]
    public DateTime LoadDateTime { get; set; }

    // Navigation properties
    public virtual ICollection<FactSales> Sales { get; set; } = new List<FactSales>();
}
