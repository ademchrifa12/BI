using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace WideWorldImportersBI.Entities.DataWarehouse;

/// <summary>
/// Customer dimension table for the Data Warehouse
/// This entity represents denormalized customer data for BI analytics
/// SCD Type 2 support with ValidFrom/ValidTo for historical analysis
/// </summary>
[Table("DimCustomer", Schema = "DW")]
public class DimCustomer
{
    [Key]
    [Column("CustomerKey")]
    public int CustomerKey { get; set; }

    /// <summary>
    /// Original CustomerID from the OLTP system (business key)
    /// </summary>
    [Column("CustomerID")]
    public int CustomerId { get; set; }

    /// <summary>
    /// Customer name at the time of the record
    /// </summary>
    [Required]
    [MaxLength(100)]
    [Column("CustomerName")]
    public string CustomerName { get; set; } = string.Empty;

    /// <summary>
    /// Customer category for segmentation analysis
    /// </summary>
    [MaxLength(100)]
    [Column("CustomerCategory")]
    public string? CustomerCategory { get; set; }

    /// <summary>
    /// Buying group for group-based analysis
    /// </summary>
    [MaxLength(100)]
    [Column("BuyingGroup")]
    public string? BuyingGroup { get; set; }

    /// <summary>
    /// City for geographic analysis
    /// </summary>
    [MaxLength(100)]
    [Column("City")]
    public string? City { get; set; }

    /// <summary>
    /// State/Province for regional analysis
    /// </summary>
    [MaxLength(100)]
    [Column("StateProvince")]
    public string? StateProvince { get; set; }

    /// <summary>
    /// Country for international analysis
    /// </summary>
    [MaxLength(100)]
    [Column("Country")]
    public string? Country { get; set; }

    /// <summary>
    /// Postal code for geographic drill-down
    /// </summary>
    [MaxLength(20)]
    [Column("PostalCode")]
    public string? PostalCode { get; set; }

    /// <summary>
    /// Credit limit for credit risk analysis
    /// </summary>
    [Column("CreditLimit")]
    public decimal? CreditLimit { get; set; }

    /// <summary>
    /// Standard discount percentage for profitability analysis
    /// </summary>
    [Column("StandardDiscountPercentage")]
    public decimal StandardDiscountPercentage { get; set; }

    /// <summary>
    /// Account opened date for customer lifetime analysis
    /// </summary>
    [Column("AccountOpenedDate")]
    public DateTime? AccountOpenedDate { get; set; }

    /// <summary>
    /// Payment terms in days
    /// </summary>
    [Column("PaymentDays")]
    public int PaymentDays { get; set; }

    /// <summary>
    /// Flag indicating if customer is on credit hold
    /// </summary>
    [Column("IsOnCreditHold")]
    public bool IsOnCreditHold { get; set; }

    /// <summary>
    /// SCD Type 2: Record validity start
    /// </summary>
    [Column("ValidFrom")]
    public DateTime ValidFrom { get; set; }

    /// <summary>
    /// SCD Type 2: Record validity end
    /// </summary>
    [Column("ValidTo")]
    public DateTime ValidTo { get; set; }

    /// <summary>
    /// SCD Type 2: Current record flag
    /// </summary>
    [Column("IsCurrent")]
    public bool IsCurrent { get; set; }

    /// <summary>
    /// ETL load timestamp
    /// </summary>
    [Column("LoadDateTime")]
    public DateTime LoadDateTime { get; set; }

    // Navigation properties
    public virtual ICollection<FactSales> Sales { get; set; } = new List<FactSales>();
}
